package bytesteams2;

public class ByteSteams2 {
}
